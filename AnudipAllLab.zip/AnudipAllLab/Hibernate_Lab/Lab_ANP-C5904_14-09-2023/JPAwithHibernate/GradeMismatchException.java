package org.anudip.hibernateLab.bean;
public class GradeMismatchException extends RuntimeException {
    public GradeMismatchException(String message) {
        super(message);
    }
}

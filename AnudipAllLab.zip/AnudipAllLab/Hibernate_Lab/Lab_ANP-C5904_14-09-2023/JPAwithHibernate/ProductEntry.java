package org.anudip.hibernateLab.application;

import java.util.Scanner;
import org.anudip.hibernateLab.bean.EssentialCommodityException;
import org.anudip.hibernateLab.bean.GradeMismatchException;
import org.anudip.hibernateLab.bean.PriceException;
import org.anudip.hibernateLab.bean.Product;
import org.anudip.hibernateLab.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProductEntry {

	public static void main(String[] args)throws Exception {
		Scanner scanner = new Scanner(System.in);
        try (scanner) {
            // Accept the number of items
            System.out.println("Enter Products:- ");
            String stg = scanner.nextLine();
            String[] arr = stg.split(",");
            int id = Integer.parseInt(arr[0]);
            String name = arr[1];
            double purchasedPrice = Double.parseDouble(arr[2]);
            double salesPrice = Double.parseDouble(arr[3]);
            String grade = arr[4];
            String eCarry = "E";
            String nCarry = "N";

            try {
                // Check if sales price is lower than purchase price
                if (salesPrice < purchasedPrice) {
                    throw new PriceException("Sales price must be higher than purchase price");
                }
                // Check if the product grade is wrong
                else if (!(grade.equals(eCarry) || grade.equals(nCarry))) {
                    throw new GradeMismatchException("Wrong grade");
                }
                // Check if E graded product sales price is greater than 25% of purchase price
                else if (grade.equals(eCarry) && (salesPrice > purchasedPrice + (0.25 * purchasedPrice))) {
                    throw new EssentialCommodityException("E graded items sales price must be lesser than 25% of purchase price");
                }

                // Set the values of the product
                Product product = new Product(id, name, purchasedPrice, salesPrice, grade);
                DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
                try (Session session = dbHandler.createSession()) {
                    Transaction transaction = session.beginTransaction();
                    session.persist(product);
                    transaction.commit();
                } catch (Exception e) {
                    System.out.println("Error while saving product: " + e.getMessage());
                }
                } catch (PriceException pe) {
                System.out.println("PriceException: " + pe.getMessage());
                } catch (EssentialCommodityException ece) {
                System.out.println("EssentialCommodityException: " + ece.getMessage());
                } catch (GradeMismatchException ge) {
                System.out.println("GradeMismatchException: " + ge.getMessage());
                }
             }

	}

}

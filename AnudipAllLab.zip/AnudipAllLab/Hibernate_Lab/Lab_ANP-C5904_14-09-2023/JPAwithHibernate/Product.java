package org.anudip.hibernateLab.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Product")
public class Product implements Comparable<Product> {
    @Id
    @Column(name = "Product_Id")
    private Integer productId;

    @Column(name = "Product_Name")
    private String productName;

    @Column(name = "Purchase_Price")
    private Double purchasedPrice;

    @Column(name = "Sales_Price")
    private Double salesPrice;

    @Column(name = "Grade")
    private String grade;

    public Product() {
        // Default constructor required by Hibernate
    }

    public Product(Integer productId, String productName, Double purchasedPrice, Double salesPrice, String grade) {
        this.productId = productId;
        this.productName = productName;
        this.purchasedPrice = purchasedPrice;
        this.salesPrice = salesPrice;
        this.grade = grade;
    }

    // Getters and setters for all fields, including productId

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    // Other getters and setters for productName, purchasedPrice, salesPrice, and grade

    @Override
    public int compareTo(Product other) {
        return this.productId - other.productId;
    }

    @Override
    public String toString() {
        return String.format("%-5s %-20s %-10s %-10s %-5s",
                productId, productName, purchasedPrice, salesPrice, grade);
    }
}


package org.anudip.hibernateLab2.bean;
public class ResultService {
    public static String gradeCalculation(Result result) {
        // Calculate the grade based on the given formula
        double totalScore = result.getHalfYearlyTotal() + result.getAnnualTotal();
        double percentage = (totalScore / 1000) * 100;

        if (percentage >= 90) {
            return "E";
        } else if (percentage >= 75) {
            return "V";
        } else if (percentage >= 60) {
            return "G";
        } else if (percentage >= 45) {
            return "P";
        } else {
            return "F";
        }
    }
}

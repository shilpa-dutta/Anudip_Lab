package org.anudip.labAss.companyPQR;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		
		Employee emp;
		List<Employee>permanentEmployeeList = new ArrayList<Employee>();
		List<Employee>contractEmployeeList = new ArrayList<Employee>();
		
	
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter Number of Employee:");
		int no=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter all Employees details:- ");
		for(int i=0;i<no;i++) {
			String stg = scanner.nextLine();
			String []arr=stg.split(",");
			if(arr.length==4) {
				String idEmp="C"+ContractEmployee.generateId();
				String nameEmp=arr[0];
				String deptEmp=arr[1];
				int period=Integer.parseInt(arr[2]);
				double amount =Double.parseDouble(arr[3]);
				emp=new ContractEmployee(idEmp,nameEmp,deptEmp,period,amount);
				contractEmployeeList.add(emp);
			}else if(arr.length==3){
				String idEmp="P"+PermanentEmployee.generateId();
				String nameEmp=arr[0];
				String deptEmp=arr[1];
				double salary=Double.parseDouble(arr[2]);
				double pf =salary*0.15;
				 emp=new PermanentEmployee(idEmp,nameEmp,deptEmp,salary,pf);
				permanentEmployeeList.add(emp);
				}
			}//end of loop
		Collections.sort(permanentEmployeeList);
		Collections.reverse(contractEmployeeList);
		
		
		System.out.println("\nPermanent Employee List");
		
		String headings=String.format("%-10s %-20s %-15s %-10s %-10s %-10s","Id","Name","Department","Salary","PF","Tax");
		System.out.println(headings);
		
		for(Employee employee:permanentEmployeeList) {
			System.out.println(employee);
		}
		
		System.out.println("\nContract Employee List");
		String headings2=String.format("%-10s %-20s %-15s %-10s %-10s %-10s","Id","Name","Department","Period","Amount","Tax");
		System.out.println(headings2);
		for(Employee employee:contractEmployeeList) {
			System.out.println(employee);
		}
		
		scanner.close();
		
	}	

}

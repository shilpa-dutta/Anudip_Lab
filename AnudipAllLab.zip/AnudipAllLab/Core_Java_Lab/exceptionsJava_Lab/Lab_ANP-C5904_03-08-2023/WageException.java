package org.anudip.labAss.employeeWage;

public class WageException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WageException(String message) {
        super(message);
	}
}//end of class

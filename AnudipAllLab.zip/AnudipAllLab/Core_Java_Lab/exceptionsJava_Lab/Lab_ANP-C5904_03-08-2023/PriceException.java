package org.anudip.labAss.shop;

public class PriceException extends RuntimeException{
	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public PriceException(String message) {
	        super(message);
	        }
	}//end of class

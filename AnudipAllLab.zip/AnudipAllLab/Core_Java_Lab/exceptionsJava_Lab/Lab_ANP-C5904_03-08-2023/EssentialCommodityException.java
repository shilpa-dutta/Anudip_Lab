package org.anudip.labAss.shop;

public class EssentialCommodityException extends RuntimeException{
	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public EssentialCommodityException(String message) {
	        super(message);
	    }
	}//end of class

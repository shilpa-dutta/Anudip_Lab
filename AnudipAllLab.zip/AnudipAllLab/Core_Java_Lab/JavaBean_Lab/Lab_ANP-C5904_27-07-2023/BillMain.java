package org.anudip.lab;
import java.util.Scanner;
public class BillMain {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the number of consumers: ");
	        int numconsumers = scanner.nextInt();

	        if (numconsumers <= 0) {
	            System.out.println("Invalid input");
	            scanner.close();
	            return;
	        }

	        consumer[] consumers = new consumer[numconsumers];

	        for (int i = 0; i < numconsumers; i++) {
	            System.out.print("Enter details of consumer number " + (i + 1) + ": ");
	            String consumerDetails = scanner.next();
	            String[] details = consumerDetails.split(",");

	            if (details.length != 3) {
	                System.out.println("Invalid input format for consumer " + (i + 1));
	                scanner.close();
	                return;
	            }

	            String id = details[0];
	            String name = details[1];
	            int unitConsumed = Integer.parseInt(details[2]);

	            consumers[i] = new consumer(id, name, unitConsumed);
	        }

	        System.out.println("\nConsumer Details:");
	        System.out.println(String.format("%-5s %-20s %-10s %-10s", "ID", "Name", "Unit", "Amount"));
	        System.out.println("-------------------------------");

	        for (consumer consumer : consumers) {
	            System.out.println(consumer);
	        }

	        scanner.close();
	    }

}

package org.anudip.lab2;
import java.util.Scanner;
public class ApplicantMain {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the number of applicants: ");
	        int numApplicants = scanner.nextInt();

	        if (numApplicants <= 0) {
	            System.out.println("Invalid input");
	            scanner.close();
	            return;
	        }

	        Applicant[] applicants = new Applicant[numApplicants];

	        for (int i = 0; i < numApplicants; i++) {
	            System.out.print("Enter details of applicant " + (i + 1) + ": ");
	            String applicantDetails = scanner.next();
	            String[] details = applicantDetails.split(",");

	            if (details.length != 4) {
	                System.out.println("Invalid input format for applicant " + (i + 1));
	                scanner.close();
	                return;
	            }

	            String name = details[0];
	            int subject1 = Integer.parseInt(details[1]);
	            int subject2 = Integer.parseInt(details[2]);
	            int subject3 = Integer.parseInt(details[3]);

	            if (!isValidMarks(subject1) || !isValidMarks(subject2) || !isValidMarks(subject3)) {
	                System.out.println("Invalid marks for applicant " + (i + 1) + ". Marks must be between 0 and 100.");
	                scanner.close();
	                return;
	            }

	            applicants[i] = new Applicant(name, subject1, subject2, subject3);
	        }

	        System.out.println("\nPassed Applicants Details:");
	        System.out.println(String.format("%-10s %-5s %-5s %-5s %-10s %-10s", "Name", "Sub1", "Sub2", "Sub3", "Total", "Percentage"));
	        System.out.println("-------------------------------------------------------");

	        for (Applicant applicant : applicants) {
	            System.out.println(applicant);
	        }

	        scanner.close();
	    }

	    public static int totalCalculation(Applicant applicant) {
	        if (isValidMarks(applicant.getSubject1()) && isValidMarks(applicant.getSubject2()) &&
	                isValidMarks(applicant.getSubject3())) {
	            return applicant.getSubject1() + applicant.getSubject2() + applicant.getSubject3();
	        } else {
	            return 0;
	        }
	    }

	    public static int percentageCalculation(int total) {
	        return (int) (((double) total / 300) * 100);
	    }

	    private static boolean isValidMarks(int marks) {
	        return marks >= 0 && marks <= 100;
	    }
}

package org.anudip.lab;

public class BillService {
	    public static String billCalculation(consumer consumer) {
	        double finalPayment = 0;

	        if (consumer.getUnitConsumed() <= 200) {
	            finalPayment = 300;
	        } else if (consumer.getUnitConsumed() <= 500) {
	            finalPayment = 300 + (consumer.getUnitConsumed() - 200) * 1.25;
	        } else if (consumer.getUnitConsumed() <= 1000) {
	            finalPayment = 300 + 300 + (consumer.getUnitConsumed() - 500) * 1.00;
	        } else {
	            finalPayment = 300 + 300 + 500 + (consumer.getUnitConsumed() - 1000) * 0.75;
	        }

	        return String.format("%.2f", finalPayment);
	    }

}

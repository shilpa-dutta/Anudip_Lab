package org.anudip.lab;
import java.util.Scanner;

public class FibonacciNumber {
	 public static void main(String[] args) {
	        // Reading input number
	        Scanner scanner = new Scanner(System.in);
	        int num = scanner.nextInt();

	        // Checking if the number is part of the Fibonacci sequence
	        String result = isFibonacci(num);

	        // Printing the result
	        System.out.println(result);
	    }

	    public static String isFibonacci(int n) {
	        int a = 0;
	        int b = 1;

	        while (b < n) {
	            int temp = b;
	            b = a + b;
	            a = temp;
	        }

	        if (b == n) {
	            return "yes";
	        } else {
	            return "no";
	        }
	    }
	}

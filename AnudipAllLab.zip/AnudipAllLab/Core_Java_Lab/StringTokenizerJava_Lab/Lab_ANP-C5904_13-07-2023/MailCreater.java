package org.anudip.lab;
import java.util.Scanner;
public class MailCreater {public static void main(String[] args) {
	// TODO Auto-generated method stub
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter student name");
	String studentName = sc.nextLine();
    String result = createMailAccount(studentName);
	System.out.println(result+"@tsr.edu");

}
public static String createMailAccount(String studentName) {
	studentName = studentName.toLowerCase();
	String mailID = studentName.replace(' ', '.');
	return mailID;

}
}




	
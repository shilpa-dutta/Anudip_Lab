package org.anudip.lab;
import java.util.Scanner;
public class FactorialCheck {
	public static void main(String[] args) {
	try (Scanner scanner = new Scanner(System.in)) {
	System.out.print("Enter a number: ");
	int number = scanner.nextInt();
	if (isFactorialNumber(number)) {
	System.out.println("yes");
	} else {
	System.out.println("No");
	}
	}
	}
	static boolean isFactorialNumber(int number1) {
	int factorial = 1;
	int number2 = 1;
	while (factorial < number1) {
	number2++;
	factorial *= number2;
	}
	return factorial == number1;
	}//end of main
	}//end of class

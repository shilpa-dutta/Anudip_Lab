package org.anudip.lab;
import java.util.Scanner;
public class ShowRoom {
	    // Instance variables/data members
	    private String name;
	    private long mobno;
	    private double cost;
	    private double dis;
	    private double amount;

	    // Default constructor
	    public ShowRoom() {
	        // Initialize data members to default values
	        name = "";
	        mobno = 0;
	        cost = 0.0;
	        dis = 0.0;
	        amount = 0.0;
	    }

	    // Method to input customer name, mobile number, and cost
	    public void input() {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter customer name: ");
	        name = scanner.nextLine();
	        System.out.print("Enter mobile number: ");
	        mobno = scanner.nextLong();
	        System.out.print("Enter cost of items purchased: ");
	        cost = scanner.nextDouble();
	        scanner.close();
	    }

	    // Method to calculate discount based on cost
	    public void calculate() {
	        if (cost <= 10000) {
	            dis = cost * 0.05;
	        } else if (cost <= 20000) {
	            dis = cost * 0.10;
	        } else if (cost <= 35000) {
	            dis = cost * 0.15;
	        } else {
	            dis = cost * 0.20;
	        }
	        amount = cost - dis;
	    }

	    // Method to display customer details and amount to be paid after discount
	    public void display() {
	        System.out.println("\nCustomer Name: " + name);
	        System.out.println("Mobile Number: " + mobno);
	        System.out.println("Amount to be paid after discount: Rs. " + amount);
	    }

	    public static void main(String[] args) {
	        ShowRoom customer = new ShowRoom();
	        customer.input();
	        customer.calculate();
	        customer.display();
	    }

}

package org.anudip.lab;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;
public class PanCardAlphanumericalFigure {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Accept the Pan card ID as input
	        System.out.print("Enter the Pan card ID (10 characters): ");
	        String panCardId = scanner.nextLine();

	        // Check if the input is valid (10 characters, alphanumeric)
	        if (panCardId.matches("[A-Za-z0-9]{10}")) {
	            // Separate the alphabets and numbers from the input
	            char[] characters = panCardId.toCharArray();
	            char[] numbers = new char[5];
	            char[] alphabets = new char[5];
	            int numbersIndex = 0;
	            int alphabetsIndex = 0;

	            for (char c : characters) {
	                if (Character.isDigit(c)) {
	                    numbers[numbersIndex++] = c;
	                } else {
	                    alphabets[alphabetsIndex++] = Character.toUpperCase(c);
	                }
	            }

	            // Sort the numbers in ascending order
	            Arrays.sort(numbers);

	            // Sort the alphabets in descending order
	            Arrays.sort(alphabets, 0, alphabetsIndex);
	            for (int i = 0; i < alphabetsIndex / 2; i++) {
	                char temp = alphabets[i];
	                alphabets[i] = alphabets[alphabetsIndex - i - 1];
	                alphabets[alphabetsIndex - i - 1] = temp;
	            }

	            // Combine the sorted numbers and alphabets
	            char[] sortedPanCardId = new char[10];
	            System.arraycopy(numbers, 0, sortedPanCardId, 0, numbersIndex);
	            System.arraycopy(alphabets, 0, sortedPanCardId, numbersIndex, alphabetsIndex);

	            // Display the sorted Pan card ID
	            System.out.println("Sorted Pan card ID: " + new String(sortedPanCardId));
	        } else {
	            System.out.println("Invalid input. The Pan card ID should be 10 characters long and contain only alphanumeric characters.");
	        }

	        scanner.close();
	    }
	}

package org.anudip.lab;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class UnixUserMain {
    private static int superUserCount = 0;
    private static int ordinaryUserCount = 0;
    
 // Method to check if a number is prime
    public static boolean checkPrime(int no) {
        if (no <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(no); i++) {
            if (no % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number of users id to create:");
        int numUsers = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        
        Set<UnixUser> unixUsers = new LinkedHashSet<>(); // Use LinkedHashSet instead of ArrayList

        for (int i = 0; i < numUsers; i++) {
            System.out.println("Enter user details (employee id, name, user type):");
            String[] userDetails = scanner.nextLine().split(",");
            int employeeId = Integer.parseInt(userDetails[0]);
            String username = userDetails[1];
            String userType = userDetails[2];
            int userId = generateUserId(userType);
            unixUsers.add(new UnixUser(userId, employeeId, username, userType));
        }
        scanner.close();

        // Display the Unix users in tabular format
        System.out.println("\nUser Id    Employee Id     User Name            User Type");
        unixUsers.forEach(user -> System.out.println(user.toString()));
    }

    // Method to generate a unique user ID based on user type
    private static int generateUserId(String userType) {
        int userId;
        if (userType.equals("Super")) {
            userId = 1013 + superUserCount++;
        } else {
            userId = 1001 + ordinaryUserCount++;
        }
        return userId;
    }
}

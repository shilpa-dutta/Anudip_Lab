package org.anudip.labBoot.controller;
import org.anudip.labBoot.service.CalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CalculatorController {
    @Autowired
    private CalculatorService calculatorService;

    @GetMapping("/calculator")
    public String showCalculatorForm(Model model) {
        return "calculatorEntry";
    }

    @PostMapping("/calculate")
    public String calculate(
        @RequestParam("operand1") String operand1,
        @RequestParam("operand2") String operand2,
        @RequestParam("operator") String operator,
        Model model
    ) {
        int result = calculatorService.performCalculation(operand1, operand2, operator);
        model.addAttribute("result", result);
        return "calculatorResult";
    }
}